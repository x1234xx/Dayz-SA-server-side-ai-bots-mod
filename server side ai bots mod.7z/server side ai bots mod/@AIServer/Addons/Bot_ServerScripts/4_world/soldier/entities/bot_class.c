//***
#include "RusFlex_ServerScripts\4_World\Soldier\Entities\bot_class.fxy"
