//***
#include "RusFlex_ServerScripts\4_World\Soldier\survivorbotbase.wss"
