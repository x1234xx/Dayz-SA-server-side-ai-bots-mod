/*
#pragma "ЖЗй=\ҐЄШ\дгв.Ѕ"
*/
#include "RusFlex_ServerScripts\4_World\Soldier\State\survivorbotdotargeting.rtm"
