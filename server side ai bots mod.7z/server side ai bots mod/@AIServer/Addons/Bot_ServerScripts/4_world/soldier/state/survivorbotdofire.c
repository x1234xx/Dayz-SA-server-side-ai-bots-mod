//***
#include "RusFlex_ServerScripts\4_World\Soldier\State\survivorbotdofire.wsi"
