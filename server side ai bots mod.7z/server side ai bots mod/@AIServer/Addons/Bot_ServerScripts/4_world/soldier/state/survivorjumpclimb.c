//***
#include "RusFlex_ServerScripts\4_World\Soldier\State\survivorjumpclimb.jpg"
