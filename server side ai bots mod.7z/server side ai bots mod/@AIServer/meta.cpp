protocol = 1;
publishedid = 2248735481;
name = "AIServer";
timestamp = 5249078192415681280;
